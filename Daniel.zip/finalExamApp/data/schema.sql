DROP TABLE IF EXISTS pokemon_list;
CREATE TABLE IF NOT EXISTS pokemon_list (
    id SERIAL PRIMARY KEY,
    name VARCHAR(40),
    url VARCHAR(255)
);