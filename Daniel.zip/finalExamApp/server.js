'use strict';

const ejs = require('ejs');
const express = require('express');
const app = express();
const superagent = require('superagent');
const pg = require('pg');
const client = new pg.Client('postgres://draq:root@localhost:5432/pokedex');
const bodyParser = require('body-parser');
const { restart } = require('nodemon');
const urlencodedParser = bodyParser.urlencoded({ extended: false});

app.set('view engine', 'ejs');
app.use(express.static('public'));
// app.use(express.urlencoded({extended: true}));

app.get('/', pokeDex);
app.get('/favorites', pokeBall);
app.post('/pokemon', urlencodedParser, (req, res) => {
    let pokeName = req.body.name;
    let pokeUrl = req.body.url;
    const sqlStatement = 'INSERT INTO pokemon_list (name, url) VALUES($1,$2);';
    const pokeSql = [pokeName, pokeUrl];
    console.log('attempting to save to pokedex');
    client.query(sqlStatement, pokeSql)
    .then( results => {
        console.log('pokemon saved to the pokedex $$$',results);
        res.redirect('/');
    }).catch(error => {
        console.log(error);
    });
    res.redirect('/');

});

function pokeBall (req, res) {
    console.log('loading favorites route');
    const sqlQuery = 'SELECT * FROM pokemon_list;'
    client.query(sqlQuery).then(results => {
        console.log(results);
        const pokemon = results.rows;
        res.render('favorites', {pokemon: pokemon});
    }).catch(error => {
        console.log(error);
    });
}

function pokeDex (req, res) {
    console.log('Dialing up the pokedex.');
    let limit = 50;
    let offset = 100;
    let nextPage = '';
    let pokeObj = {
        pokedoor: [],
        pokedex: []
    };
    const url = `https://pokeapi.co/api/v2/pokemon`;
    const pageUrl = `https://pokeapi.co/api/v2/pokemon?limit=${limit}&offset=${offset}`;
    superagent(url)
    .then(results => {
        nextPage = results.body.next;
       // console.log("this is next page: ",nextPage);
        //console.log("this is the results.body.results: ",results.body.results);
        results.body.results.forEach(pokemon => { 
            pokeObj.pokedoor.push(new Pokemon(pokemon.name,pokemon.url));
        });
        pokeObj.pokedoor.sort( (a,b) => {
            if(a.name > b.name) {
                return -1;
            }
            if(b.name < a.name) {
                return 1;
            } else {
                return 0;
            }
        });
        for (let i = pokeObj.pokedoor.length-1; i >= 0; i--) {
            pokeObj.pokedex.push(pokeObj.pokedoor[i]);
        }
        //console.log(pokeObj);
        res.render('show', {pokeObj: pokeObj});
        // .then(results => console.log('the .then results after creation: ',results))
    // })  
    // .then(results => {
    //         res.render('pokedex', {results: results});
    }).catch(error => {
        console.log(error, 'We caught this one, but with errors, you never really catch them all...');
    });
}


function Pokemon(name, url){
    this.name = name;
    this.url = url;
}
client.connect().then( () => {
    app.listen(3002, () => {console.log('Up and running on port 3002');
})
});
