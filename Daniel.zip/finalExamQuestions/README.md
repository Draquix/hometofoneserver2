# 301 Final Exam Challenges

This directory contains five code challenges much like the code challenges you have been doing throughout Code-301

## Before you begin

- Install your dependencies
- Run `npm test` to ensure that your tests are working (they should all fail at this point)

## Solve the challenges

- Solve each challenge
- Run `npm test` after each challenge to ensure that your solution is passing
