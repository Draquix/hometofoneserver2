'use strict';

const request = require('supertest');
/*
-------------------------------------------------------------------
Build a simple express server.
  - Connect a '/hello' route that sends a greeting of your  choice.
  - Connect a '/aboutme' route that sends a short bio about you to the front-end.
  - Connect a '/favoritefoods' route that sends an array containing your favorite foods.
  - All other routes should respond with a status of 404.

NOTE: You do not need write the app.listen() code for your server
      The test do this for you
-------------------------------------------------------------------
*/

const createServer = () => {
  const express = require('express');
  const app = express();
  app.use(express.urlencoded({extended: true}));


  app.get('/hello', helloWorld);
  app.get('/aboutme', shortBio);
  app.get('/favoritefoods', whatIEat);

  function helloWorld (req, res) {
    res.send('Wasup world!');
  }
  function shortBio (req,res) {
    res.send('My name is Daniel Rogahn, I am a student with DeltaV code academy just finishing up code 301.  I have an AA from Kirkwood CCU as a preschool teacher and a 15 year old son.  I have been coding as a hobby since I was 12 and have learned BASIC, C++, C#, Python, and JavaScript to varying extents.');
  }
  function whatIEat (req,res) {
    const foods = ['The Impossible Whopper', 'Tofu Pad Thai', 'Capriottis Veggie Cheesesteak', 'California Kithen Four Cheese Pizza', 'Freddies Garden Burger'];
    res.send(foods);
  }

  return app;
};


///////////////////////////////////////////////////
// TESTS
///////////////////////////////////////////////////

describe('Testing challenge', () => {

  let server = createServer();

  it('responds to /hello', function testSlash() {
    return request(server)
      .get('/hello')
      .then(response => {
        expect(response.status).toEqual(200);
        expect(response.text).toBeDefined();
      })
  });

  it('responds to /aboutme', function testAbout() {
    return request(server)
      .get('/aboutme')
      .then(response => {
        expect(response.status).toEqual(200);
        expect(response.text).toBeDefined();
      })
  });

  it('responds to /favoritefoods', function testFood() {
    return request(server)
      .get('/favoritefoods')
      .then(response => {
        expect(response.status).toEqual(200);
        expect(response.body.length).toBeGreaterThan(1);
      })
  });

  test('responds to /foo', function testNotFound() {
    return request(server)
      .get('/foo')
      .then(response => {
        expect(response.status).toEqual(404);
      })
  });
});
